# LiveKit Agent Environment Setup Script
# Run this script to set up all required environment variables

Write-Host "Setting up LiveKit Agent environment variables..." -ForegroundColor Cyan

# LiveKit Server Configuration
$env:LIVEKIT_URL = "wss://gemini-integration-pxcg6ngt.livekit.cloud"
$env:LIVEKIT_API_KEY = "API2L4oYScFxfvr"
$env:LIVEKIT_API_SECRET = "vgdeTSniXEACMV4tLePmPEGw48HIEPL8xsxDKKlwJ8U"

Write-Host "✓ LiveKit URL: $env:LIVEKIT_URL" -ForegroundColor Green
Write-Host "✓ LiveKit API Key: $env:LIVEKIT_API_KEY" -ForegroundColor Green
Write-Host "✓ LiveKit API Secret: [HIDDEN]" -ForegroundColor Green

# Google API Key Configuration
$env:GOOGLE_API_KEY = "AIzaSyB3qcopiW3k4BAVWNVVJ3OKLiEpPVgP-Vw"
Write-Host "✓ GOOGLE_API_KEY is set (length: $($env:GOOGLE_API_KEY.Length))" -ForegroundColor Green

Write-Host "`nEnvironment setup complete!" -ForegroundColor Cyan
Write-Host "`nTo test the setup:" -ForegroundColor Cyan
Write-Host "  python test_full_setup.py" -ForegroundColor White
Write-Host "`nTo run the agent:" -ForegroundColor Cyan
Write-Host "  python livekit_agent.py console  # Terminal mode (no server needed)" -ForegroundColor White
Write-Host "  python livekit_agent.py dev      # Development mode" -ForegroundColor White
Write-Host "  python livekit_agent.py start   # Production mode" -ForegroundColor White


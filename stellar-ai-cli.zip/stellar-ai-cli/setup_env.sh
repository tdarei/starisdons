#!/bin/bash
# LiveKit Agent Environment Setup Script
# Run this script to set up all required environment variables

echo "Setting up LiveKit Agent environment variables..."

# LiveKit Server Configuration
export LIVEKIT_URL="wss://gemini-integration-pxcg6ngt.livekit.cloud"
export LIVEKIT_API_KEY="API2L4oYScFxfvr"
export LIVEKIT_API_SECRET="vgdeTSniXEACMV4tLePmPEGw48HIEPL8xsxDKKlwJ8U"

echo "✓ LiveKit URL: $LIVEKIT_URL"
echo "✓ LiveKit API Key: $LIVEKIT_API_KEY"
echo "✓ LiveKit API Secret: [HIDDEN]"

# Google API Key Configuration
export GOOGLE_API_KEY="AIzaSyB3qcopiW3k4BAVWNVVJ3OKLiEpPVgP-Vw"
echo "✓ GOOGLE_API_KEY is set (length: ${#GOOGLE_API_KEY})"

echo ""
echo "Environment setup complete!"
echo ""
echo "To test the setup:"
echo "  python test_full_setup.py"
echo ""
echo "To run the agent:"
echo "  python livekit_agent.py console  # Terminal mode (no server needed)"
echo "  python livekit_agent.py dev      # Development mode"
echo "  python livekit_agent.py start     # Production mode"


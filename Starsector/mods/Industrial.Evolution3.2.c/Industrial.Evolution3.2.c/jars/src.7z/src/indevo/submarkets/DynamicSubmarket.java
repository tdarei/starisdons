package indevo.submarkets;

public interface DynamicSubmarket {
    void prepareForRemoval();
}

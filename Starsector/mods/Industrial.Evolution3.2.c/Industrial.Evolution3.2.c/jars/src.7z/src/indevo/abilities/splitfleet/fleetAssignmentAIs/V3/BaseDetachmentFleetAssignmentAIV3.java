package indevo.abilities.splitfleet.fleetAssignmentAIs.V3;

public class BaseDetachmentFleetAssignmentAIV3 {
    //Same thing with the modes
    //instead of following the player fleet, follow a token that follows the player fleet while it is not in-system
    //when in system, follow player fleet
    //update token and assignment to new one when player fleet jumps
    //have a listener for transversing, no-jumppoint systems and gates
    //have a listener for behaviour overrides
}

package indevo.abilities.splitfleet.dialogue;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;

public interface SplinterFleetDialoguePluginAPI {
    public void showBaseOptions();

    public InteractionDialogAPI getDialog();
}

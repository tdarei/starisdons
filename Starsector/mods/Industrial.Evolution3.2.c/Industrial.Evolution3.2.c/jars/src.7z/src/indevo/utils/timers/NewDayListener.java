package indevo.utils.timers;

public interface NewDayListener {
    void onNewDay();
}

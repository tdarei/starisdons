package com.fs.starfarer.api.plugins;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.CampaignInputListener;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.conditions.GrandColonies_CrampedCondition;
import com.fs.starfarer.api.impl.campaign.econ.impl.conditions.GrandColonies_PageNumCondition;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.input.InputEventType;
import org.apache.log4j.Logger;

import java.awt.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GrandColonies_modPlugin extends BaseModPlugin {

    public static final Logger log = Global.getLogger(GrandColonies_modPlugin.class);
    public static final char TARGET_CHAR = Global.getSettings().getString("GrandColonies_TogglePageButton").charAt(0);
    public static final String PAGE_CONDITION_ID = "GrandColonies_pageCond";
    public static final String PAGE_CONDITION_KEY = "$GrandColonies_pageCond";
    public static final String DOCKED_KEY = "$GrandColonies_docked";
    public static final String EXCLUDED_IDS = "$GrandColonies_excl";

    @Override
    public void onGameLoad(boolean newGame) {
        super.onGameLoad(newGame);

        Global.getSector().addTransientListener(new PlayerOpenedMarketListener(false));
    }

    public static class PlayerOpenedMarketListener extends BaseCampaignEventListener {
        public PlayerOpenedMarketListener(boolean permaRegister) {
            super(permaRegister);
        }

        @Override
        public void reportPlayerOpenedMarket(MarketAPI market) {
            if (market == null || !market.isPlayerOwned()) return;
            if (market.isPlanetConditionMarketOnly()) {
                log.info("Clearing a condition market of Grand.Colony Traces");
                removeNoToggle(market);
                Global.getSector().getListenerManager().removeListenerOfClass(ButtonPressListener.class);
                return;
            }

            Global.getSector().getListenerManager().addListener(new ButtonPressListener(market), true);

            setDocked(market, true);
            initCond(market);
            initPages(market);

            GrandColonies_PageNumCondition.getCondition(market).setPage(GrandColonies_PageNumCondition.Page.ONE);
        }

        @Override
        public void reportPlayerClosedMarket(MarketAPI market) {
            if (!market.hasCondition(PAGE_CONDITION_ID)) return;

            setDocked(market, false);
            Global.getSector().getListenerManager().removeListenerOfClass(ButtonPressListener.class);
            resetMarket(market, !market.isPlayerOwned());
        }

        private void setDocked(MarketAPI market, boolean docked){
            if (docked) market.getMemoryWithoutUpdate().set(DOCKED_KEY, true);
            else market.getMemoryWithoutUpdate().unset(DOCKED_KEY);
        }

    }

    private static class ButtonPressListener implements CampaignInputListener {
        private MarketAPI market;
        private boolean listenForMove = false;

        public ButtonPressListener(MarketAPI market) {
            this.market = market;
        }

        @Override
        public int getListenerInputPriority() {
            return 0;
        }

        @Override
        public void processCampaignInputPreCore(List<InputEventAPI> events) {
            if (market.isPlanetConditionMarketOnly()) {
                log.info("Aborting Grand.Colony implementation, clearing condition market of traces");
                removeNoToggle(market);
                Global.getSector().getListenerManager().removeListener(this);
                return;
            }

            for (InputEventAPI input : events) {
                if (input.isConsumed()) continue;

                if (listenForMove && !input.getEventType().equals(InputEventType.KEY_DOWN)) {
                    pressM();
                    listenForMove = false;
                    return;
                }

                if (input.getEventType().equals(InputEventType.KEY_DOWN)) {
                    if (Character.toLowerCase(input.getEventChar()) == TARGET_CHAR) {
                        toggle(market, true);
                        updateUnhideableCountAndCondition(market);
                        listenForMove = true;
                        return;
                    }
                }
            }
        }

        @Override
        public void processCampaignInputPreFleetControl(List<InputEventAPI> events) {
        }

        @Override
        public void processCampaignInputPostCore(List<InputEventAPI> events) {

        }
    }

    public static void toggle(MarketAPI market, boolean refresh) {
        GrandColonies_PageNumCondition cond = GrandColonies_PageNumCondition.getCondition(market);
        MemoryAPI mem = market.getMemoryWithoutUpdate();
        Set<String> excl = (Set<String>) mem.get(EXCLUDED_IDS);

        for (Industry ind : market.getIndustries()) {
            if (excl.contains(ind.getId())) continue;

            if (!ind.isHidden()) {
                ind.setHidden(true);
            } else {
                ind.setHidden(false);
            }
        }

        //to make sure we don't exceed the count with all the unhideables, adjust the page one hidden industries before refreshing
        if (cond.currentPage.equals(GrandColonies_PageNumCondition.Page.TWO)) initPages(market);

        if (refresh) pressM();

        cond.flipPage();
    }

    public static void pressM() {
        try {
            Robot r = new Robot();

            r.keyPress(77);
            r.keyRelease(77);

        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static void initCond(MarketAPI market) {
        if (!market.hasCondition(PAGE_CONDITION_ID)) {
            String token = market.addCondition(PAGE_CONDITION_ID);
            market.getMemoryWithoutUpdate().set(PAGE_CONDITION_KEY, token);
        }

        if (!market.hasCondition(GrandColonies_CrampedCondition.CONDITION_ID))
            market.addCondition(GrandColonies_CrampedCondition.CONDITION_ID);
    }

    private static void initPages(MarketAPI market) {
        Set<String> excl = initExcl(market);
        Set<String> notHideable = updateUnhideableCountAndCondition(market);

        int totalAllowedOnFirstPage = 12 - notHideable.size();

        //rehide excess above page one count
        for (Industry ind : market.getIndustries()) {
            if (excl.contains(ind.getId()) || notHideable.contains(ind.getId())) continue;
            if (totalAllowedOnFirstPage > 0) {
                totalAllowedOnFirstPage--;
                continue;
            }

            ind.setHidden(true);
        }
    }

    private static Set<String> updateUnhideableCountAndCondition(MarketAPI market) {
        Set<String> excl = initExcl(market);
        Set<String> notHideable = new HashSet<>();
        GrandColonies_PageNumCondition cond = GrandColonies_PageNumCondition.getCondition(market);
        cond.clearUnhideableMessage();

        int totalInQueue = market.getConstructionQueue().getItems().size();

        //unhide all, or don't if it's just an update
        for (Industry ind : market.getIndustries()) {
            if (excl.contains(ind.getId())) continue;
            if (ind.isHidden()) continue;

            ind.setHidden(true);
            if (!ind.isHidden()) notHideable.add(ind.getId());
            ind.setHidden(false);
        }

        int totalPossibleOnFistPage = 12 - notHideable.size() - totalInQueue;

        //set cond todisplay warnings if the first page is filled with unhideables
        cond.displayUnhideablesMessage(totalInQueue, notHideable, totalPossibleOnFistPage <= 0);

        return notHideable;
    }

    private static void removeNoToggle(MarketAPI market) {
        MemoryAPI mem = market.getMemoryWithoutUpdate();
        mem.unset(EXCLUDED_IDS);
        market.removeCondition(PAGE_CONDITION_ID);
        mem.unset(PAGE_CONDITION_KEY);
    }

    private static void resetMarket(MarketAPI market, boolean withRemoval) {
        MemoryAPI mem = market.getMemoryWithoutUpdate();
        Set<String> excl = (Set<String>) mem.get(EXCLUDED_IDS);

        GrandColonies_PageNumCondition cond = GrandColonies_PageNumCondition.getCondition(market);
        if (cond.currentPage.equals(GrandColonies_PageNumCondition.Page.TWO)) toggle(market, false);

        if(excl != null){
            for (Industry ind : market.getIndustries()) {
                if (excl.contains(ind.getId())) continue;
                if (ind.isHidden()) ind.setHidden(false);
            }
        }

        mem.unset(EXCLUDED_IDS);

        if (withRemoval) {
            market.removeCondition(PAGE_CONDITION_ID);
            mem.unset(PAGE_CONDITION_KEY);
        }
    }

    //store all hidden industries in the condition / list when docking and except them from toggle to avoid toggling stuff you shouldn't
    private static Set<String> initExcl(MarketAPI market) {
        MemoryAPI mem = market.getMemoryWithoutUpdate();
        if (mem.contains(EXCLUDED_IDS)) return (Set<String>) mem.get(EXCLUDED_IDS);

        Set<String> excl = new HashSet<>();
        for (Industry ind : market.getIndustries()) if (ind.isHidden()) excl.add(ind.getId());
        mem.set(EXCLUDED_IDS, excl);
        return excl;
    }
}

package com.fs.starfarer.api.impl.campaign.econ.impl.conditions;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignUIAPI;
import com.fs.starfarer.api.campaign.CoreUITabId;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.plugins.GrandColonies_modPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.campaign.econ.Market;
import org.apache.log4j.Logger;

import java.awt.*;
import java.util.HashSet;
import java.util.Set;

import static com.fs.starfarer.api.campaign.CoreUITabId.OUTPOSTS;
import static com.fs.starfarer.api.plugins.GrandColonies_modPlugin.*;

public class GrandColonies_PageNumCondition extends BaseMarketConditionPlugin {
    public static final Logger log = Global.getLogger(GrandColonies_PageNumCondition.class);

    public enum Page {
        ONE,
        TWO
    }

    private Set<String> unhideables = new HashSet<>();
    private int inCostructionQueue = 0;
    private boolean warn = false;
    public Page currentPage = Page.ONE;

    public void setPage(Page page){
        currentPage = page;
    }
    public void flipPage(){
        currentPage = currentPage.equals(Page.ONE) ? Page.TWO : Page.ONE;
    }

    public static GrandColonies_PageNumCondition getCondition(MarketAPI market){
        MemoryAPI mem = market.getMemoryWithoutUpdate();
        if (!mem.contains(PAGE_CONDITION_KEY) || !market.hasCondition(PAGE_CONDITION_ID)) GrandColonies_modPlugin.initCond(market);

        return ((GrandColonies_PageNumCondition) market.getSpecificCondition(mem.getString(PAGE_CONDITION_KEY)).getPlugin());
    }

    public void displayUnhideablesMessage(int inCOnstructionQueue, Set<String> unhideables, boolean warn){
        this.inCostructionQueue = inCOnstructionQueue;
        this.unhideables = unhideables;
        this.warn = warn;
    }

    public void clearUnhideableMessage(){
        unhideables.clear();
        inCostructionQueue = 0;
        warn = false;
    }

    private boolean isDocked(MarketAPI market){
        return market.getMemoryWithoutUpdate().getBoolean(DOCKED_KEY);
    }

    @Override
    public String getIconName() {
        if(!isDocked(market)) return Global.getSettings().getSpriteName("GrandColonies", "warn_low");
        if(warn) return Global.getSettings().getSpriteName("GrandColonies", "warn");
        return Global.getSettings().getSpriteName("GrandColonies", currentPage.equals(Page.ONE) ? "01" : "02");
    }

    @Override
    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
        super.createTooltipAfterDescription(tooltip, expanded);

        if(!isDocked(market)){
            tooltip.addPara("Unable to toggle pages while not docked at the colony!", Misc.getNegativeHighlightColor(), 10f);
            return;
        }

        String pgStr = currentPage.toString().toLowerCase();
        String charStr = Character.toString(GrandColonies_modPlugin.TARGET_CHAR).toUpperCase();

        tooltip.addPara("Currently on page " + pgStr + ".", 10f, Misc.getHighlightColor(), pgStr);
        tooltip.addPara("Press " + charStr + " to switch page.", 3f, Misc.getHighlightColor(), charStr);

        if(warn){
            tooltip.addPara("The total amount of items in the construction queue + unhideable buildings exceeds 12. Wait for some constructions " +
                    "to finish or remove an unhideable building to restore capacity.", Misc.getNegativeHighlightColor(), 10f);
        }

        if(unhideables.size() > 0) {
            String amt = unhideables.size() + " buildings";
            tooltip.addPara( amt + " can not be hidden.", 10f, Misc.getHighlightColor(), amt);
        }

        if (inCostructionQueue > 0){
            String amt = inCostructionQueue + " buildings";
            tooltip.addPara( amt + " in the construction queue can not be hidden.", unhideables.size() > 0 ? 3f : 10f, Misc.getHighlightColor(), amt);
        }
    }

    @Override
    public boolean showIcon() {
        return market.isPlayerOwned();
    }
}

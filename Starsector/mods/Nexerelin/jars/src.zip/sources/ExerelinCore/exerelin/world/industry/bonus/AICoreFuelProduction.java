package exerelin.world.industry.bonus;

import com.fs.starfarer.api.impl.campaign.ids.Industries;

public class AICoreFuelProduction extends AICore {
	
	public AICoreFuelProduction() {
		super(Industries.FUELPROD);
	}
}
